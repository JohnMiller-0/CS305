package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{   
	
	@RequestMapping("/hash")
	public String myHash(){
		String data = "John's Check Sum";
		String hash = calculateHash(data);


		return "<p>data:"+data+" SHA - 256: "+hash;
	}

	public static String calculateHash(String name) {
		try {
			// Create a MessageDigest instance for SHA-256 hashing
			MessageDigest digest = MessageDigest.getInstance("SHA-256");

			// Compute the hash of the input string 'name' using UTF-8 encoding
			byte[] hash = digest.digest(name.getBytes(StandardCharsets.UTF_8));

			// Convert the resulting byte array into a hexadecimal string
			return bytesToHex(hash);
		} catch (NoSuchAlgorithmException e) {
			// Print the stack trace if the SHA-256 algorithm is not available
			e.printStackTrace();
			return null;
		}
	}

	private static String bytesToHex(byte[] bytes) {
		// Create a StringBuilder to hold the hexadecimal representation of the byte array
		StringBuilder hexString = new StringBuilder(2 * bytes.length);

		// Iterate over each byte in the array
		for (byte b : bytes) {
			// Convert the byte to a hexadecimal string
			String hex = Integer.toHexString(0xff & b);

			// Ensure each hex string is two characters long by appending '0' if necessary
			if (hex.length() == 1) {
				hexString.append('0');
			}

			// Append the hex string to the StringBuilder
			hexString.append(hex);
		}

		// Return the complete hexadecimal string
		return hexString.toString();
	}
}